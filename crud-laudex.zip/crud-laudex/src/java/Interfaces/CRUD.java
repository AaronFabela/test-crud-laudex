package Interfaces;

import Modelo.Alumno;
import java.util.List;

/**
 *
 * @author AaronFabela
 */
public interface CRUD {
    public List listar();
    public Alumno list(int id);
    public boolean add(Alumno alu);
    public boolean edit(Alumno alu);
    public boolean eliminar(int id);
}
