package Controlador;

import Modelo.Alumno;
import ModeloDAO.AlumnoDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author AaronFabela
 */
public class Controlador extends HttpServlet {
    
    String listar="vistas/lista.jsp";
    String agregar="vistas/agregar.jsp";
    String editar="vistas/editar.jsp";
    Alumno a = new Alumno();
    AlumnoDAO dao = new AlumnoDAO();
    int id;
    
    
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sesion = request.getSession();
        if(sesion.getAttribute("usuario")!=null){
            String accion = request.getParameter("accion");
            switch(accion){
                case "Principal":
                    request.getRequestDispatcher("principal.jsp").forward(request, response);
                    break;
                default:
                    throw new AssertionError();
            } 
        }
        else{
            sesion.setAttribute("mensaje","Debes iniciar sesión para ingresar a todas las funciones");
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sesion = request.getSession();
        String acceso = "";
        if(sesion.getAttribute("usuario")!=null){
            String accion = request.getParameter("accion");

            if(accion.equalsIgnoreCase("listar")){
                acceso = listar;
            }
            else if(accion.equalsIgnoreCase("add")){
                acceso = agregar;
            }
            else if(accion.equalsIgnoreCase("editar")){
                request.setAttribute("idAlumno",request.getParameter("id"));
                acceso = editar;
            }
            else if(accion.equalsIgnoreCase("eliminar")){
                id = Integer.parseInt(request.getParameter("id"));
                a.setId(id);
                dao.eliminar(id);
                acceso = listar;
            }
            else if(accion.equalsIgnoreCase("Principal")){
                acceso = "principal.jsp";
            }
            else if(accion == null){
                System.out.print("sou nll");
                response.sendRedirect("index.jsp");
            }
        }
        else{
            sesion.setAttribute("mensaje","Debes iniciar sesión para ingresar a todas las funciones");
            acceso = "index.jsp";
        }
        RequestDispatcher vista = request.getRequestDispatcher(acceso);
        vista.forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sesion = request.getSession();
        String acceso = "";
        if(sesion.getAttribute("usuario")!=null){
            String accion = request.getParameter("accion");
            if(accion.equalsIgnoreCase("Agregar")){
                String nombre = request.getParameter("nombre");
                String apellidoPaterno = request.getParameter("apellidoPaterno");
                String apellidoMaterno = request.getParameter("apellidoMaterno");
                String nacimiento = request.getParameter("nacimiento");
                String sexo = request.getParameter("sexo");
                String estudios = request.getParameter("estudios");
                String email = request.getParameter("email");
                String telefono = request.getParameter("telefono");
                a.setNombre(nombre);
                a.setApellidoPaterno(apellidoPaterno);
                a.setApellidoMaterno(apellidoMaterno);
                a.setNacimiento(nacimiento);
                a.setSexo(sexo);
                a.setEstudios(estudios);
                a.setEmail(email);
                a.setTelefono(telefono);
                dao.add(a);
                acceso = listar;
            }
            else if(accion.equalsIgnoreCase("Actualizar")){
                id = Integer.parseInt(request.getParameter("id"));
                String nombre = request.getParameter("nombre");
                String apellidoPaterno = request.getParameter("apellidoPaterno");
                String apellidoMaterno = request.getParameter("apellidoMaterno");
                String nacimiento = request.getParameter("nacimiento");
                String sexo = request.getParameter("sexo");
                String estudios = request.getParameter("estudios");
                String email = request.getParameter("email");
                String telefono = request.getParameter("telefono");
                a.setId(id);
                a.setNombre(nombre);
                a.setApellidoPaterno(apellidoPaterno);
                a.setApellidoMaterno(apellidoMaterno);
                a.setNacimiento(nacimiento);
                a.setSexo(sexo);
                a.setEstudios(estudios);
                a.setEmail(email);
                a.setTelefono(telefono);
                dao.edit(a);
                acceso = listar;
            }
            else if(accion.equalsIgnoreCase("Principal")){
                acceso = "principal.jsp";
            }
        }
        else{
            sesion.setAttribute("mensaje","Debes iniciar sesión para ingresar a todas las funciones");
            acceso = "index.jsp";
        }
        RequestDispatcher vista = request.getRequestDispatcher(acceso);
        vista.forward(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
