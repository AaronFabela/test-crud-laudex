package Config;

import java.sql.*;

/**
 *
 * @author AaronFabela
 */
public class Conexion {
    Connection con;
    
    public Conexion(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3307/crud_laudex","root","12345678");
        }
        catch(Exception e){
            System.err.println("Error "+e);
        }
    }
    
    public Connection getConnection(){
        return con;
    }
}
