/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloDAO;

import Config.Conexion;
import Modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author AaronFabela
 */
public class UsuarioDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    
    public Usuario validar(String usuario, String password){
        Usuario u = new Usuario();
        String sql = "SELECT * FROM usuarios WHERE usuario=? AND contrasena=?";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1,usuario);
            ps.setString(2,password);
            rs = ps.executeQuery();
            while(rs.next()){
                u.setId(rs.getInt("id"));
                u.setNombre(rs.getString("usuario"));
                u.setContrasena(rs.getString("contrasena"));
            }
        }
        catch(Exception e){
            System.err.print(e);
        }
        return u;
        
    }
    
}
