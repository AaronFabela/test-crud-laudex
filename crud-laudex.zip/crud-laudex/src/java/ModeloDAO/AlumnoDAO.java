/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloDAO;

import Config.Conexion;
import Interfaces.CRUD;
import Modelo.Alumno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author AaronFabela
 */
public class AlumnoDAO implements CRUD{
    
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Alumno a = new Alumno();

    @Override
    public List listar() {
        ArrayList<Alumno>list = new ArrayList<>();
        String sql = "SELECT * FROM alumnos";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Alumno alu = new Alumno();
                alu.setId(rs.getInt("id"));
                alu.setNombre(rs.getString("nombre"));
                alu.setApellidoPaterno(rs.getString("apellidoPaterno"));
                alu.setApellidoMaterno(rs.getString("apellidoMaterno"));
                alu.setNacimiento(rs.getString("nacimiento"));
                alu.setSexo(rs.getString("sexo"));
                alu.setEstudios(rs.getString("estudios"));
                alu.setEmail(rs.getString("email"));
                alu.setTelefono(rs.getString("telefono"));
                list.add(alu);
                
            }
        }
        catch(Exception e){
        }
        
        return list;
    }

    @Override
    public Alumno list(int id) {
        String sql = "SELECT * FROM Alumnos WHERE id="+id;
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                a.setId(rs.getInt("id"));
                a.setNombre(rs.getString("nombre"));
                a.setApellidoPaterno(rs.getString("apellidoPaterno"));
                a.setApellidoMaterno(rs.getString("apellidoMaterno"));
                a.setNacimiento(rs.getString("nacimiento"));
                a.setSexo(rs.getString("sexo"));
                a.setEstudios(rs.getString("estudios"));
                a.setEmail(rs.getString("email"));
                a.setTelefono(rs.getString("telefono"));
                
            }
        }
        catch(Exception e){
            System.err.print(e);
        }
        
        return a;
    }

    @Override
    public boolean add(Alumno alu) {
        String sql = "INSERT INTO Alumnos (nombre,apellidoPaterno,apellidoMaterno,nacimiento,sexo,estudios,email,telefono) VALUES ( '"+alu.getNombre()+"','"+alu.getApellidoPaterno()+"','"+alu.getApellidoMaterno()+"','"+alu.getNacimiento()+"','"+alu.getSexo()+"','"+alu.getEstudios()+"','"+alu.getEmail()+"','"+alu.getTelefono()+"')";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            System.out.print("Lo hice");
        }
        catch(Exception e){
            System.err.print(e);
        }
        return false;
    }

    @Override
    public boolean edit(Alumno alu) {
        String sql = "UPDATE Alumnos set nombre='"+alu.getNombre()+"',apellidoPaterno='"+alu.getApellidoPaterno()+"',apellidoMaterno='"+alu.getApellidoMaterno()+"',nacimiento='"+alu.getNacimiento()+"',sexo='"+alu.getSexo()+"',estudios='"+alu.getEstudios()+"',email='"+alu.getEmail()+"',telefono='"+alu.getTelefono()+"' WHERE id="+alu.getId();
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        }
        catch(Exception e){
            System.err.print(e);
        }
        
        return false;
    }

    @Override
    public boolean eliminar(int id) {
        String sql = "DELETE FROM Alumnos WHERE id="+id;
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        }
        catch(Exception e){
            System.err.print(e);
        }
        
        return false;
    }
    
}
